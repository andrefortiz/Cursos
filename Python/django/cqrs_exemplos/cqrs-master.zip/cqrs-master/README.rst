CQRS Inspired Helpers
=====================

Designed to help Django projects communicating with a Meteor UI layer.

Note: this project is only _indicative_ of what CQRS is.  As we learn more, it'll also evolve.
