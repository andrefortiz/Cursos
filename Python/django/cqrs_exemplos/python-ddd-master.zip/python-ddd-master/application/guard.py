# def goard_not_empty(value):
#     pass
