class IdentityHashingService:
    def hash(self, value):
        return value
