class NotFoundException(Exception):
    pass