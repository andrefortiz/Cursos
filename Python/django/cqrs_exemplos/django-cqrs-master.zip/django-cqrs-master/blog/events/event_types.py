class EventTypes:
    post_created_event = 'PostCreatedEvent'
    post_updated_event = 'PostUpdatedEvent'
