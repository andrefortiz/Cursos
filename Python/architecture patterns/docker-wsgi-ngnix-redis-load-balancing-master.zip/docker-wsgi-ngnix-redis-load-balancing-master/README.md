
# Learn how to combine Nginx + wigs + load balancing + flask + unit testing + Docker 


<img width="758" alt="Screen Shot 2020-04-05 at 9 15 11 AM" src="https://user-images.githubusercontent.com/39345855/78499490-003e5d00-771f-11ea-9acc-23455e0e1f78.png">



## Youtube Video : https://www.youtube.com/watch?v=45Jqr3DYjh8
